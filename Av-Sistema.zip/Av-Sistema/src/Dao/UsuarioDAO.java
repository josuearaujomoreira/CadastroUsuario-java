package Dao;

import Factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.Usuario;

/**
 *
 * @author Josué
 */
public class UsuarioDAO {
    private Connection connection;
    long idusuario;
    String nome;
    String cpf;
    String email;
    String telefone;
    ResultSet rs;
    ArrayList<Usuario> lista = new ArrayList<>();
   
    public UsuarioDAO(){
        //APROPIADO DO MÉTODO DE CONEXÃO 
        this.connection  = new ConnectionFactory().getConnection(); 
    }
    public void adciona(Usuario usuario) throws Exception{
        //comando sql 
        String sql = "INSERT INTO usuario(nome,cpf,email,telefone) values(?,?,?,?)";
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1,usuario.getNome());
            stmt.setString(2,usuario.getCpf());
            stmt.setString(3,usuario.getEmail());
            stmt.setString(4, usuario.getTelefone());
            stmt.execute();
            stmt.close();
        }catch(SQLException u){
            throw new Exception("Erro ao inserir usuário");
        }
    }
    // buscar
    public ArrayList<Usuario> Pesquisar(){
        String sql = "SELECT * FROM usuario";
       
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
             rs =stmt.executeQuery();
             
             //laço para ler todas as linhas
             while(rs.next()){
                 Usuario obejto = new Usuario();
                 obejto.setId(rs.getInt("Id"));
                 obejto.setNome(rs.getString("nome"));
                 obejto.setCpf(rs.getString("cpf"));
                 obejto.setEmail(rs.getString("email"));
                 obejto.setTelefone(rs.getString("telefone"));
                 
                 lista.add(obejto);
             }
            
        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null,"UsuarioDAO:" + erro);
        }
        return lista;
    }
    
    public void Alterar(Usuario usuario) throws Exception{
        //comando sql 
        String sql = "UPDATE usuario SET nome= ?,cpf =?,email = ?,telefone = ? WHERE id = ?;";
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1,usuario.getNome());
            stmt.setString(2,usuario.getCpf());
            stmt.setString(3,usuario.getEmail());
            stmt.setString(4,usuario.getTelefone());            
            stmt.setInt(5,usuario.getId());            
            stmt.execute();
            stmt.close();
        }catch(SQLException u){
            throw new Exception("Erro ao Alterar informações do Aluno");
        }
    }
    
    
    public void excluircampos(Usuario usuario){
        String sql = "DELETE  from  usuario where id = ?";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1,usuario.getId());
            stmt.execute();
            stmt.close();
            
        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null,"erro la"+erro);
        }

    }
}
