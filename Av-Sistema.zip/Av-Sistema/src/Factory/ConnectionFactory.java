package Factory;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author Josué
 */
public class ConnectionFactory {
     public Connection getConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://localhost/bd_cadastrousuario","root","");
        }
        catch(ClassNotFoundException e){
            throw new RuntimeException(e);
        }
        catch(SQLException excecao) {
               throw new RuntimeException(excecao);
        }
     }
}
     

