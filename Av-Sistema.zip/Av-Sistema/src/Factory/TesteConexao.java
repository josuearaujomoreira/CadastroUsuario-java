//package Factory;
//import java.sql.SQLException;

/**
 *
 * @author Josué
 */
//public class TesteConexao {
 //  public static void main (String[] args) throws SQLException{
   //     java.sql.Connection connection = new ConnectionFactory().getConnection();
    //    System.out.println("Conexão aberta");
    //    connection.close();
  //  }
//}
